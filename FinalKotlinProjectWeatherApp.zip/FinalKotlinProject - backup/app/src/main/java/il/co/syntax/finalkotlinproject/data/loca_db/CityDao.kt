package il.co.syntax.finalkotlinproject.data.loca_db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import il.co.syntax.finalkotlinproject.data.models.City


@Dao
interface CityDao {

    @Query("SELECT * FROM cities ORDER BY name ASC")
    fun getAllCities() : LiveData<List<City>>

    @Query("SELECT * FROM cities WHERE name = :name ")
    fun getCity(name : String) : LiveData<City>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCity(city: City)

    @Delete
    suspend fun deleteCity (vararg city: City)

    //for delete all
    @Query("DELETE from cities")
    fun deleteAll()

    @Query("SELECT * FROM cities WHERE isFavorite = :isFavorite")
    fun getCitiesByFavorite(isFavorite: Boolean): LiveData<City>

    @Query("UPDATE cities SET isFavorite = 0")
    suspend fun updateAllCitiesAsNotFavorite()

    @Query("UPDATE cities SET isFavorite = 1 WHERE name = :cityName")
    suspend fun updateCityAsFavorite(cityName: String)


}