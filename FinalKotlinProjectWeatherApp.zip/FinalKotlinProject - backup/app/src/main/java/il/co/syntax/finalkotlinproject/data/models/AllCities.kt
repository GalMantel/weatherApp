package il.co.syntax.finalkotlinproject.data.models

import com.google.gson.annotations.SerializedName

data class AllCities(
    val name: String,
    @SerializedName("weather") val weather: List<Weather>,
    @SerializedName("main") val main: Main
) {}


data class Main(
    val temp :Double,
    val temp_min : Double,
    val temp_max : Double
)

