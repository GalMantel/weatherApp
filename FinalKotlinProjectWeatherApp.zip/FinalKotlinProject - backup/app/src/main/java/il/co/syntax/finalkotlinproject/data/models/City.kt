package il.co.syntax.finalkotlinproject.data.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "cities")
data class City(
    @PrimaryKey
    val name: String,
    val main:String ? = null,
    val description:String ? = null,
    val temp :Double,
    val temp_min : Double,
    val temp_max : Double,
    val icon: String ? = null,

    @ColumnInfo(name = "isFavorite")
    val isFavorite : Boolean = false
)
{

}





