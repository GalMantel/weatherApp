package il.co.syntax.finalkotlinproject.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cities_names")
data class CityName (
    @PrimaryKey
    val id: Int,
    val name: String ? = null,
    val state: String ? = null,
    val country: String ? = null,
) {}