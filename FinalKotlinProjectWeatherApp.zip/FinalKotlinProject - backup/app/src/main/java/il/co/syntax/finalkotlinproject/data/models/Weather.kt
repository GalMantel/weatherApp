package il.co.syntax.finalkotlinproject.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weather")
data class Weather(
    @PrimaryKey
    val id:Int,
    val main:String ? = null,
    val description:String ? = null,
    val icon:String ? = null
)
{

}