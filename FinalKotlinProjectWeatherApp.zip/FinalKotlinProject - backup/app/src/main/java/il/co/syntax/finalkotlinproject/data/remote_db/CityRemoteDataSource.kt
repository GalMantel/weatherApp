package il.co.syntax.finalkotlinproject.data.remote_db

import il.co.syntax.finalkotlinproject.utils.Constants.Companion.appid
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class CityRemoteDataSource @Inject constructor(
    private val cityInterface:CityService) : BaseDataSource() {

    suspend fun getCities(q: String = "Tel Aviv") = getResult { cityInterface.getAllCities( q, appid = appid) }
}