package il.co.syntax.finalkotlinproject.data.remote_db

import il.co.syntax.finalkotlinproject.data.models.AllCities
import il.co.syntax.finalkotlinproject.utils.Constants.Companion.data
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query


interface CityService {

    @GET(data)
    suspend fun getAllCities(
        @Query("q") q: String,
        @Query("appid") appid: String
    ): Response<AllCities>


}