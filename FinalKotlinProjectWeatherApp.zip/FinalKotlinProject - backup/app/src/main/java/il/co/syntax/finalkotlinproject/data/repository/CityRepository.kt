package il.co.syntax.finalkotlinproject.data.repository


import il.co.syntax.finalkotlinproject.data.loca_db.CityDao
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.data.remote_db.CityRemoteDataSource
import il.co.syntax.finalkotlinproject.utils.performFetchFromLocal
import il.co.syntax.finalkotlinproject.utils.performFetchingAndSaving
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CityRepository @Inject constructor(
    private val remoteDataSource : CityRemoteDataSource,
    private val localDataSource : CityDao
){

    fun getCities(city_name: String = "") = performFetchingAndSaving(
        { localDataSource.getAllCities()},
        {remoteDataSource.getCities(city_name)},
        {
            if (it != null) {
                localDataSource.insertCity(City(it.name, it.weather[0].main, it.weather[0].description,
                 it.main.temp, it.main.temp_min, it.main.temp_max, it.weather[0].icon))
            }
        }
    )

    fun getCity(q : String) = performFetchingAndSaving(
        {localDataSource.getCity(q)},
        {remoteDataSource.getCities(q)},
        {
            if (it != null) {
                localDataSource.insertCity(City(it.name, it.weather[0].main, it.weather[0].description,
                    it.main.temp, it.main.temp_min, it.main.temp_max, it.weather[0].icon))
            }
        }

    )

    fun getFavoriteCity() = performFetchFromLocal {
        localDataSource.getCitiesByFavorite(true)
    }

    suspend fun updateFavoriteCity(name : String) = withContext(Dispatchers.IO) {
        localDataSource.updateAllCitiesAsNotFavorite()
        localDataSource.updateCityAsFavorite(name)
    }

    suspend fun deleteCity(city: City){
        localDataSource.deleteCity(city)
    }

    //for delete all
    suspend fun deleteAll(){
        localDataSource.deleteAll()
    }
}

