package il.co.syntax.finalkotlinproject.ui.all_cities

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.R
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.databinding.CitiesFragmentBinding
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Success
import il.co.syntax.finalkotlinproject.utils.Error
import il.co.syntax.fullarchitectureretrofithiltkotlin.utils.autoCleared
import kotlinx.coroutines.launch
import android.util.Log


@AndroidEntryPoint
class AllCitiesFragment : Fragment() {

    private val viewModel: AllCitiesViewModel by viewModels()

    private var binding: CitiesFragmentBinding by autoCleared()

    private lateinit var adapter: CitiesAdapter


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = CitiesFragmentBinding.inflate(inflater, container, false)
        binding.convertAction.setOnClickListener {
            findNavController().navigate(R.id.action_allCitiesFragment_to_allCitiesFahrenheitFragment)
        }
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        adapter = CitiesAdapter(object : CitiesAdapter.CityItemListener {
            override fun onCityClick(cityId: String) {
                val args = Bundle()
                args.putString(getString(R.string.city_id), cityId)

                findNavController().navigate(
                    R.id.action_allCitiesFragment_to_singleCityFragment,
                    args
                )
            }
        })
        binding.citiesRv.layoutManager = LinearLayoutManager(requireContext())
        binding.citiesRv.adapter = adapter

        viewModel.cities.observe(viewLifecycleOwner) {
            when (it.status) {
                is Loading -> binding.progressBar.visibility = View.VISIBLE

                is Success -> {
                    binding.progressBar.visibility = View.GONE
                    adapter.setCities(it.status.data!!)
                }

                is Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), it.status.message, Toast.LENGTH_LONG).show()
                }
            }
        }

        //for delete all
        fun onMenuItemSelected(menuItem: MenuItem): Boolean {
            return when (menuItem.itemId) {
                R.id.action_delete -> {
                    showConfirmationDialog()
                    true
                }
                else -> false
            }
        }


        //search view
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                performSearch(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })

        val cities = viewModel.getCities("")
        viewModel.refreshData()

        ItemTouchHelper(object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            ) = makeFlag(ItemTouchHelper.ACTION_STATE_SWIPE, ItemTouchHelper.LEFT)

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            //Delete an item by swipe to the left
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val cityToDelete = adapter.cities[viewHolder.adapterPosition] // Save item to delete
                showIndividualConfirmationDialog(cityToDelete, viewHolder.adapterPosition) // Call confirmation dialog'
            }


        }).attachToRecyclerView(binding.citiesRv)

    }
    private fun logWeatherUpdate(cities: List<City>) {
        for (city in cities) {
            Log.d(getString(R.string.all_cities_fragment_f), getString(R.string.massage_weather_update)+{city.name})
        }
    }


//        override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
//            return when (menuItem.itemId) {
//                R.id.action_delete -> {
//                    showConfirmationDialog()
//                    true
//                }
//                else -> false
//            }
//        }

    //for search bar
    private fun performSearch(query: String) {
        // Make your API call here using the query value
        // For example, you can call your view model's searchMovies() function
        viewModel.getCities(query)
    }


    //Confirmation Dialog for individual items
    private fun showIndividualConfirmationDialog(cityToDelete: City, position: Int) {
        val alertDialogBuilder = AlertDialog.Builder(requireContext())
        alertDialogBuilder.setTitle((getString(R.string.delete_city)))
        alertDialogBuilder.setMessage(getString(R.string.are_you_sure_city))
        alertDialogBuilder.setPositiveButton(getString(R.string.delete)) { dialogInterface: DialogInterface, _: Int ->
            viewModel.delete(cityToDelete) // Delete the confirmed item
            Toast.makeText(requireContext(), getString(R.string.city_deleted), Toast.LENGTH_LONG)
                .show()
            binding.citiesRv.adapter!!.notifyItemRemoved(position) // Notify adapter
            dialogInterface.dismiss()
        }
        alertDialogBuilder.setNegativeButton(getString(R.string.cancel)) { dialogInterface: DialogInterface, _: Int ->
            binding.citiesRv.adapter!!.notifyItemChanged(position) // If deletion cancelled, refresh the item to its original state
            dialogInterface.dismiss()
        }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }


    //delete All Dialog
    fun showConfirmationDialog() {
        val alertDialogBuilder = AlertDialog.Builder(requireContext())
        alertDialogBuilder.setTitle(getString(R.string.delete_title))
        alertDialogBuilder.setMessage(getString(R.string.delete_item))
        alertDialogBuilder.setPositiveButton(getString(R.string.delete)) { dialogInterface: DialogInterface, _: Int ->
            lifecycleScope.launch {
                viewModel.deleteAll()
            }
            dialogInterface.dismiss()
        }
        alertDialogBuilder.setNegativeButton(getString(R.string.cancel)) { dialogInterface: DialogInterface, _: Int ->
            dialogInterface.dismiss()
        }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }


}