package il.co.syntax.finalkotlinproject.ui.all_cities

import androidx.lifecycle.*
import dagger.hilt.android.lifecycle.HiltViewModel
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.data.repository.CityRepository
import il.co.syntax.finalkotlinproject.utils.Resource
import il.co.syntax.finalkotlinproject.utils.Success
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class AllCitiesViewModel @Inject constructor(
    private val cityRepository: CityRepository
) : ViewModel() {
    private val _cities = MutableLiveData<Resource<List<City>>>()
    val cities: LiveData<Resource<List<City>>>
        get()= _cities


    fun getCities(query: String) {
        _cities.value = Resource.loading(null)
        cityRepository.getCities(query).observeForever { resource ->
            if (resource != null) {
                _cities.value = resource
            }
        }
    }


    fun refreshData() {
        viewModelScope.launch {
            val citiesResource: LiveData<Resource<List<City>>> = cityRepository.getCities()
            citiesResource.observeForever { resource ->
                if (resource != null && resource.status is Success) {
                    val cities: List<City> = resource.status.data ?: emptyList()
                    cities.forEach { city ->
                        cityRepository.getCity(city.name)
                    }
                }
            }
        }
    }

    fun delete(city: City) {
        viewModelScope.launch(Dispatchers.IO) {
            cityRepository.deleteCity(city)
        }
    }

    //for delete all
    suspend fun deleteAll() {
        cityRepository.deleteAll()
    }
}
