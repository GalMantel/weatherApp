package il.co.syntax.finalkotlinproject.ui.all_cities

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.databinding.ItemCityBinding
import il.co.syntax.finalkotlinproject.ui.single_city.SingleCityFragment.Companion.KelvinToCelsius


class CitiesAdapter(private val listener: CityItemListener) :  //was mutable list
    RecyclerView.Adapter<CitiesAdapter.CityViewHolder>() {

    val cities = ArrayList<City>()

    class CityViewHolder(private val itemBinding: ItemCityBinding,
                              private val listener: CityItemListener)
        : RecyclerView.ViewHolder(itemBinding.root),
        View.OnClickListener {

        private lateinit var city: City
        companion object {
            val weatherIcons = mapOf(

                "01d" to "24a", "01n" to "24b",
                "02d" to "22a", "02n" to "22b",
                "03d" to "23a", "03n" to "23b",
                "04d" to "20", "04n" to "20",
                "09d" to "9", "09n" to "9",
                "10d" to "14", "10n" to "14",
                "11d" to "2", "11n" to "2",
                "13d" to "6", "13n" to "6",
                "50d" to "17", "50n" to "17",
            )
        }


        init {
            itemBinding.root.setOnClickListener(this)
        }

        fun bind(item: City) {
            this.city = item
            itemBinding.name.text = item.name
            itemBinding.temp.text = KelvinToCelsius(city.temp).toInt().toString()

            val imgUrl ="https://worldweather.wmo.int/images/${weatherIcons[item.icon]}.png"
            val imgUri = imgUrl.toUri().buildUpon().scheme("https").build()
            Glide.with(itemBinding.root).load(imgUri).circleCrop().into(itemBinding.image)

        }

        override fun onClick(v: View?) {
            listener.onCityClick(city.name)
        }

    }

    fun setCities(cities : Collection<City>) {
        this.cities.clear()
        this.cities.addAll(cities)
        notifyDataSetChanged()
    }



    override fun onBindViewHolder(holder: CityViewHolder, position: Int) =
        holder.bind(cities[position])


    override fun getItemCount() = cities.size

    interface CityItemListener {
        fun onCityClick(cityId : String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        val binding = ItemCityBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return CityViewHolder(binding,listener)
    }

}
