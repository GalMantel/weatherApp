package il.co.syntax.finalkotlinproject.ui.favorite_city_fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.R
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.databinding.FavoriteCityFragmentBinding
import il.co.syntax.finalkotlinproject.ui.all_cities.CitiesAdapter
import il.co.syntax.finalkotlinproject.ui.single_city.SingleCityFragment
import il.co.syntax.finalkotlinproject.utils.Error
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Success

@AndroidEntryPoint
class FavoriteCityFragment : Fragment() {

    private var _binding: FavoriteCityFragmentBinding? = null
    private val binding get() = _binding!!
    private val viewModel: FavoriteCityViewModel by activityViewModels()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FavoriteCityFragmentBinding.inflate(inflater, container, false)
        arguments?.getString(getString(R.string.city))?.let {
            Toast.makeText(requireActivity(), it, Toast.LENGTH_SHORT).show()
        }

        binding.allCitiesAction.setOnClickListener {
            findNavController().navigate(R.id.action_favoriteCityFragment_to_allCitiesFragment)
        }
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.city.observe(viewLifecycleOwner) {
            when (it.status) {
                is Success -> {
                    if (it.status.data != null) {
                        updateCity(it.status.data)
                    }
                }


                is Loading -> {

                }
                is Error -> {
                    Toast.makeText(requireContext(), it.status.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    private fun updateCity(city: City) { // change to the fields of city
        binding.name.text = city.name
        binding.temp.text = SingleCityFragment.KelvinToCelsius(city.temp).toInt().toString()
        binding.descriptionVal.text = city.description
        binding.main.text = city.main
        binding.maxTemperatureVal.text = SingleCityFragment.KelvinToCelsius(city.temp_max).toInt().toString()
        binding.minTemperatureVal.text = SingleCityFragment.KelvinToCelsius(city.temp_min).toInt().toString()

        val imgUrl = "https://worldweather.wmo.int/images/${CitiesAdapter.CityViewHolder.weatherIcons[city.icon]}.png"
        val imgUri = imgUrl.toUri().buildUpon().scheme("https").build()
        Glide.with(requireContext()).load(imgUri).circleCrop().into(binding.image)


    }
}