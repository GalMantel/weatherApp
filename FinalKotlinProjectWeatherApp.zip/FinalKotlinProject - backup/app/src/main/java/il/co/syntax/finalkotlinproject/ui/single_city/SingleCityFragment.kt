package il.co.syntax.finalkotlinproject.ui.single_city

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.bumptech.glide.Glide
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.R
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.databinding.CityDetailFragmentBinding
import il.co.syntax.finalkotlinproject.ui.all_cities.CitiesAdapter.CityViewHolder.Companion.weatherIcons
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Success
import il.co.syntax.finalkotlinproject.utils.Error
import il.co.syntax.fullarchitectureretrofithiltkotlin.utils.autoCleared

@AndroidEntryPoint
class SingleCityFragment : Fragment() {

    private val viewModel : SingleCityViewModel by viewModels()
    private var binding : CityDetailFragmentBinding by autoCleared()
    private lateinit var city : City

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = CityDetailFragmentBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.city.observe(viewLifecycleOwner) {
            when(it.status) {
                is Success -> {
                    binding.progressBar.visibility = View.GONE
                    updateCity(it.status.data!!)
                    city = it.status.data!!
                    binding.cityCl.visibility = View.VISIBLE
                }
                is Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.cityCl.visibility = View.GONE
                }
                is Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(),it.status.message,Toast.LENGTH_LONG).show()
                }
            }
        }

        arguments?.getString("cityId")?.let {
            viewModel.setId(it)
        }
        binding.addToFavorite!!.setOnClickListener {
            viewModel.updateFavorite(city.name)
            Toast.makeText(context, getString(R.string.add_to_fav), Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateCity(city:City) { // change to the fields of city
        binding.name.text = city.name
        binding.temp.text = KelvinToCelsius(city.temp).toInt().toString()
        binding.descriptionVal.text = city.description
        binding.main.text = city.main
        binding.maxTemperatureVal.text = KelvinToCelsius(city.temp_max).toInt().toString()
        binding.minTemperatureVal.text = KelvinToCelsius(city.temp_min).toInt().toString()

        val imgUrl = "https://worldweather.wmo.int/images/${weatherIcons[city.icon]}.png"
        val imgUri = imgUrl.toUri().buildUpon().scheme("https").build()
        Glide.with(requireContext()).load(imgUri).circleCrop().into(binding.image)
    }
    companion object {
        fun KelvinToCelsius(temp: Double) = temp - 273.15
    }


}