package il.co.syntax.finalkotlinproject.ui.single_city

import androidx.lifecycle.*
import dagger.hilt.android.lifecycle.HiltViewModel
import il.co.syntax.finalkotlinproject.data.models.City
import il.co.syntax.finalkotlinproject.data.repository.CityRepository
import il.co.syntax.finalkotlinproject.utils.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SingleCityViewModel @Inject constructor(
    private val cityRepository: CityRepository
): ViewModel() {
    private val _id =  MutableLiveData<String>()

    private val _city = _id.switchMap {
        cityRepository.getCity(it)
    }

    val city : LiveData<Resource<City>> = _city

    fun setId(id : String) {
        _id.value = id
    }


    fun updateFavorite(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            cityRepository.updateFavoriteCity(name)
        }
    }
}