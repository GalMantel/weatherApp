package il.co.syntax.finalkotlinproject.utils

class Constants {

    companion object {
        const val BASE_URL = "https://api.openweathermap.org/"
        const val appid = "eca110e432dbc01408a6898056a273cd"
        const val data = "data/2.5/weather"
    }
}